function inserir(num){
    document.querySelector('.tela').innerHTML += num;
}

function AC() {
    document.querySelector('.tela').innerHTML = "";
}

function DE() {
    let tela = document.querySelector('.tela').innerHTML;
    document.querySelector('.tela').innerHTML = tela.substring(0, tela.length - 1);
}

function calcular() {
    let tela = document.querySelector('.tela').innerHTML;
    if(tela)
        document.querySelector('.tela').innerHTML = eval(tela).toFixed(4);
    else
        document.querySelector('.tela').innerHTML = "ERROR";
}
