function colors() {
    let red = document.getElementById('red').value;
    let green = document.getElementById('green').value;
    let blue = document.getElementById('blue').value;
    let bg = document.querySelector(".box");
    bg.style.backgroundColor = 'rgb('+ red +','+ green +','+ blue +')';    
}
