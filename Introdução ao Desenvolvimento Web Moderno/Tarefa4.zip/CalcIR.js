function calcular() {
    let valor = document.querySelector(".entrada input").value;
    //Calculo da base de calculo do IR
    if(valor > 0 && valor <= 1302)
        valor = valor - valor*0.075;
    else if(valor > 1302 && valor <= 2571.29)
        valor =  valor - (valor-1302)*0.09 - 97.65;
    else if(valor > 2571.29 && valor <= 3856.94)
        valor = valor - (valor-2571.29)*0.12 - 211.88;
    else if(valor > 3856.94 && valor <= 7507.49)
        valor = valor - (valor-3856.94)*0.14 - 366.15;
    else if(valor > 7507.49){
        valor = valor - 877.22;
    }

    //Calculo do IR
    document.querySelector('.resultado').innerHTML = 'R$';
    if(valor <= 1903.98 && valor > 0){
        document.querySelector('.resultado').innerHTML = "Isento de imposto.";
    } else if(valor > 1903.98 && valor <= 2826.65){
        document.querySelector('.resultado').innerHTML += (valor*0.075 - 142.8).toFixed(2);
    } else if(valor > 2826.65 && valor <= 3751.05){
        document.querySelector('.resultado').innerHTML += (valor*0.15 - 354.8).toFixed(2);
    } else if(valor > 3751.05 && valor <= 4664.68){
        document.querySelector('.resultado').innerHTML += (valor*0.225 - 636.13).toFixed(2);
    } else if(valor > 4664.68){
        document.querySelector('.resultado').innerHTML += (valor*0.275 - 869.36).toFixed(2);
    } else {
        document.querySelector('.resultado').innerHTML = "Insira um valor valido.";
    }
}
