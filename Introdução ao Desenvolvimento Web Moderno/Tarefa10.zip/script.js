const form = document.getElementById('userForm');

form.addEventListener('submit', e => {
    e.preventDefault();

    const nome = document.getElementById('nome').value;
    const email = document.getElementById('email').value;
    const curso = document.getElementById('curso').value;

    fetch('/usuarios', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({nome,email,curso})
    })
        .catch(error => {
            console.error('Erro ao salvar usuário:', error);
        });
});

