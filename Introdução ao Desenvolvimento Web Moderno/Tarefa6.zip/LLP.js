let integrantes = [];
let cont = 0;

function agrupar(e){
    if(cont < 4){
        integrantes[cont++] = e.innerHTML;
        let pessoa = document.createElement("button");
        pessoa.setAttribute("id", "alunos");
        pessoa.setAttribute("onclick", "voltar(this)");
        pessoa.innerHTML = e.innerHTML;
        document.querySelector('.equipe').appendChild(pessoa);
        e.parentNode.removeChild(e);
    }
}

function criar(){
    if(cont == 3 || cont == 4){
        let grupo = new Map();
        let nomeDoGrupo = document.querySelector('input');
        grupo.set("nome", nomeDoGrupo.value);
        grupo.set(0, integrantes[0]);
        grupo.set(1, integrantes[1]);
        grupo.set(2, integrantes[2]);
        if(cont == 4)
            grupo.set(3, integrantes[3]);
        nomeDoGrupo.value = "";
        let p = document.querySelectorAll('.equipe #alunos');
        for(let i=0; i<p.length; i++)
            p[i].parentNode.removeChild(p[i]);
        result(grupo);
    }
}

function result(grupo){
    
    let div = document.createElement("div");
    document.querySelector('.resultado').appendChild(div);
    div.style.border = "2px solid black";
    div.style.margin = "5px";
    div.style.padding = "5px";
    div.style.cursor = "pointer";
    div.setAttribute('onclick', 'voltarDiv(this)');


    let nomeDoGrupo = document.createElement("h4");
    nomeDoGrupo.innerHTML = grupo.get("nome");
    div.appendChild(nomeDoGrupo);
    
    for(let i=0; i<cont; i++){
        let aluno = document.createElement("p"); 
        aluno.innerHTML = grupo.get(i);
        aluno.className = "p";
        div.appendChild(aluno);
    }
    document.querySelector('.resultado').appendChild(div);
    cont = 0;
}

function voltar(e){
    let button = document.createElement("button");
    button.setAttribute("onclick", "agrupar(this)");
    button.innerHTML = e.innerHTML;
    document.querySelector('.alunos').appendChild(button);
    e.parentNode.removeChild(e);
    cont--;
}

function voltarDiv(div){
    let nomes = div.children;
    console.log(nomes.length);
    for(let i=nomes.length-1; i>=0; i--){
        if(nomes[i].className == "p"){
            console.log(nomes[i]);
            voltar(nomes[i]);
        }
        else
            div.removeChild(nomes[i]);
    }
    div.parentNode.removeChild(div);
    if(cont<0)
        cont=0;
}
