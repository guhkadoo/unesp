let rightItems = new Set();
let leftItems = new Set();

function addRightItems(e){
    rightItems.clear();
    rightItems.add(e);
}

function addLeftItems(e){
    leftItems.clear();
    leftItems.add(e);
}

function sendLeft(){
    for(const x of rightItems.values()){
        let td = document.createElement("td");
        let button = document.createElement("button");
        button.setAttribute('onclick', 'addLeftItems(this)');
        button.innerHTML = x.innerHTML;
        td.appendChild(button);
        x.parentNode.removeChild(x);
        document.querySelector('.leftTable').appendChild(td);
        document.querySelector('.LB1 p').innerHTML++;
        document.querySelector('.LB2 p').innerHTML--;
    }
}

function sendRight(){
    for(const x of leftItems.values()){
        let td = document.createElement("td");
        let button = document.createElement("button");
        button.setAttribute('onclick', 'addRightItems(this)');
        button.innerHTML = x.innerHTML;
        td.appendChild(button);
        x.parentNode.removeChild(x);
        document.querySelector('.rightTable').appendChild(td);
        document.querySelector('.LB1 p').innerHTML--;
        document.querySelector('.LB2 p').innerHTML++;
    }
}

function clearAll(){
    window.location.reload();
}
