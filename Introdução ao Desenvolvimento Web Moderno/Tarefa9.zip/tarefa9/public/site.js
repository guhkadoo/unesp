document.querySelector('.enviar').addEventListener('click', () =>{
    let id = document.querySelector('.idEnviar').value;
    let nome = document.querySelector('.nome').value;
    let email = document.querySelector('.email').value;
    let qry = '/insere/' + id + '/' + nome + '/' + email;
    fetch(qry, {
        method: 'PUT'
    })
        .then(res => res.text())
        .catch(error => console.error(error))
    dados();
});

document.querySelector('.deletar').addEventListener('click', () =>{
    let id = document.querySelector('.idDeletar').value;
    let qry = '/apaga/' + id;
    fetch(qry, {
        method: 'DELETE'
    })
        .then(res => res.text())
        .catch(error => console.error(error))
    dados();
})

function dados(){
    fetch('/usuarios', {
        method: 'GET'
    })
        .then(res => res.json())
        .then(data => {
            let usuariosContainer = document.querySelector('.mostra');
            usuariosContainer.innerHTML = '<div><h2>Usuarios</h2></div>'; // Limpa o conteúdo anterior
            data.forEach(usuario => {
                let usuarioDiv = document.createElement('div');
                usuarioDiv.style.border = '2px solid black';
                usuarioDiv.style.borderRadius = '10px';
                usuarioDiv.style.padding = '5px';
                usuarioDiv.style.margin = '5px';
                usuarioDiv.innerHTML = `<p>ID: ${usuario.id}</p><p>Nome: ${usuario.nome}</p><p>Email: ${usuario.email}</p>`;
                usuariosContainer.appendChild(usuarioDiv);
            });
        })
        .catch(error => console.error(error));
}
