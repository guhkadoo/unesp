// Express.js - Framework orientado a rotas

const express = require("express");
const fs = require("fs");
const app = express();
const porta = 3000;

var array = {
    pessoas: []
}

app.post('/registro/:nome/:email/:senha', (req, res) => {
    let dados = req.params;
    array.pessoas.push(dados);
    let dadosJSON = JSON.stringify(array, null, 2)

    fs.writeFile('pessoas.json', dadosJSON, () => {})
    console.log(JSON.stringify(dados, null, 2));
});

app.listen(porta, function() {
   console.log(`Servidor iniciado na porta ${porta}\nOs registros sao salvos em "pessoas.json"\ncurl -X POST localhost:3000/:nome/:email/:senha`);
});
