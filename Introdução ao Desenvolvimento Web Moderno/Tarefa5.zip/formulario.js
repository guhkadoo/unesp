function enviar(){
    let dados = document.getElementsByName('label');
    let erro = 0;
    for(let i=0; i<dados.length; i++){
        if(dados[i].value == "" || dados[i].value == null)
            erro = 1;
        console.log(JSON.stringify(dados[i].value));
    }
    if(erro){
        alert("Insira as informacoes corretamente.");
        return false;
    }
}

function dentro(id){
    id.style.background = 'rgba(85, 54, 124, 0.6000000238418579)';
}

function fora(id){
    id.style.background = '#D2BFFF';
}
